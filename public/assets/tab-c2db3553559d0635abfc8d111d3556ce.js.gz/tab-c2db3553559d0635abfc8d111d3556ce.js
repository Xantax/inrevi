
  $(function() {
    $( "#tabs" ).tabs();
  });

